package kr.swdl;

import java.util.Date;

public interface MemberService {
	public MemberVO CreateMember(String memberId, String name,char gender, int point, Date date);
}
