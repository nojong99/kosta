package kr.swdl.model;
// 생성자가 없다. 접근할 수 있는 방법은 static -> 대문자를 쓰는 final
public interface Query {
	String ADMIN_LOGIN = "select name from admin_customer where admin_id=? and pw=?";
	String GET_CUSTOMERS = " select customer_no, name, point from customers order by customer_no desc";
	String GET_CUSTOMER = "select name from customers where customer_no=?";
	String ADD_CUSTOMER = "insert into customers (customer_no, name, phone_no, in_date) values (customer_no_seq.nextval, ?, ?, sysdate)";
	String UPDATE_POINT = "update customers set point=nvl(point, 0) +? where customer_no=?";
	String GET_CUSTOMER_ID = "select customer_no_seq.currval from dual";
}
