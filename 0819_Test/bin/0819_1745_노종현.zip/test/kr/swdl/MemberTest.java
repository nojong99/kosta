package test.kr.swdl;

import java.util.Date;

import kr.swdl.MemberService;
import kr.swdl.MemberServiceAType;

public class MemberTest {

	public static void main(String[] args) {
		MemberService service;
		service = new MemberServiceAType();
		System.out.println(service.CreateMember("nojong", "j3", 'M', 10, new Date()));
	}

}
