package kr.swdl.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import kr.swdl.model.CustomerDAO;
import kr.swdl.model.CustomerService;
import kr.swdl.model.DBCP;

public class LoginAction implements Action {

	@Override
	public String execute(HttpServletRequest request) throws ServletException, IOException {
		
		
		// 나중에 DAO 연결해서 로그인 처리 
		// 로그인 여부에 따라 url이 달라져야함..
		
		String url="login.html"; // 다시 
		String name = new CustomerService().login(request.getParameter("id"),request.getParameter("pw"));
		if(name !=null) {// 로그인 승인 상태
			url = "view/adminOK.jsp";
			//로그인 여부 session - 접속하면 제공 메모리
			HttpSession session = request.getSession(true); // 세션이 있으면 전달 없으면 새로
			session.setAttribute("loginOK", request.getParameter("id")); // 프라이머리 키를 유지해야함
			session.setAttribute("loginName", name);
		}
		return url;
	}

}
