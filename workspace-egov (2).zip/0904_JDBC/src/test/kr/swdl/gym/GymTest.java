package test.kr.swdl.gym;

import java.sql.SQLException;

import kr.swdl.gym.dao.GymMemberDAO;

public class GymTest {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		GymMemberDAO Gym = new GymMemberDAO();
//		System.out.println(Gym.loginAdminInfo("A020", "nojong123"));
//		System.out.println(Gym.getMemberList());
//		Gym.getMemberInfo("20");
//		System.out.println(Gym.getPassList());
		System.out.println(Gym.updatePass("14", "헬스 5개월권", 500000, "5개월권 생김"));
	}
}
