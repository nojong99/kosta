<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
	<h1>등록된 고객 리스트</h1>
	<%@ include file="adminOK.jsp" %>
<!-- </%/@/p/a/g/e/%/> < - import처럼 앞에서 선언할 때, utf-8처럼 서블릿 앞에서 한 느낌 -->
<!-- 고객 등록은 관리자가 해야한다. -->
<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<table border="1">
	<tr><td>고객번호</td><td>고객이름</td><td>보유 포인트</td></tr>
	<c:forEach items="${list}" var="customer">
	<tr><td>${customer.customerId}</td>
	<td>${customer.name}</td><td>${customer.point}</td></tr>
	</c:forEach>
</table>

