package kr.swdl;

import java.util.Date;

public class MemberServiceAType implements MemberService{
	
	
	
	@Override
	public MemberVO CreateMember(String memberId, String name, char gender, int point, Date date){
		MemberVO membervo = null;
		try {
			membervo = new MemberVO(memberId, name, gender, point, date);
		} catch (NameSizeException | GenderValueException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return membervo;
	}
	

}
