package kr.swdl.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
// 불린으로 던지기로함
public class CustomerService {
	
	
	
	public List<CustomerVO> getCustomers(){
		try {
			return new CustomerDAO(DBCP.getConnection()).getCustomers();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	/**일반적으로 회원 가입 - 포인트 없음.*/
	public boolean addCustomer(String name, String phoneNo) {
		try {
			return new CustomerDAO(DBCP.getConnection()).addCustomer(name, phoneNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/** 이벤트 기간에는 특정 포인트를 회원 등록 시 부여 */
	public boolean addCustomer(String name, String phoneNo, int point) {
		// point 만 추가 시키는 방법 -> insert & update / point는 가변이 되어야함.
		// insert 뿐아니라 update 재사용성 높다. 쿼리문 2개 ㅎㅎ
		// point 의 값이 없음 update customers set point=nvl(point,?) +10 where customer_no=?;
		boolean result = false;
		Connection conn=null;
		try {
			conn = DBCP.getConnection();
			conn.setAutoCommit(false); // 쿼리문을 한번날릴게 아니라 오토커밋 해제!!!
			CustomerDAO dao = new CustomerDAO(conn);
			// 서비스 / dao를 온전하게 만들고 서비스는 다리 역할~
			if(dao.addCustomer(name, phoneNo)){ //1
				int customerId = dao.getCustomerId(); //2
				if(dao.updateCustmerPoint(customerId, point)) { //3
					conn.commit(); //4 
					result = true;
				}
			}
			
		} catch (SQLException e) {
			try {
				conn.rollback(); // << 얘도 오류날 수 있음
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				conn.setAutoCommit(false);// 빌려왔다라고 생각하면 원상복구 해놓아야한다.
				conn.close(); // 자원 반환
			} catch (SQLException e) {
				e.printStackTrace();
			} 
		}
		
		
		
		return result;
	}
	public String login(String adminId, String pw) {
		try {
			return new CustomerDAO(DBCP.getConnection()).login(adminId, pw);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
}
